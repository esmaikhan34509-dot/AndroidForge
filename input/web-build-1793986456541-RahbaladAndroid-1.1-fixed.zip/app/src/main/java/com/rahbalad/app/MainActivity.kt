package com.rahbalad.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Brand = Color(0xFF087F78)
private val BrandDark = Color(0xFF06645F)
private val Background = Color(0xFFF4F7F7)
private val Ink = Color(0xFF17252B)
private val Muted = Color(0xFF718087)
private val UserBubble = Color(0xFFE1F3F0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RahbaladApp() }
    }
}

private data class ChatMessage(val text: String, val fromUser: Boolean)
private data class Feature(
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val prompt: String
)

private val features = listOf(
    Feature("فهمیدن نامه", "نامه و مدارک اداری", Icons.Default.Description,
        "می‌خواهم متن یک نامه را ساده و قابل‌فهم توضیح بدهی. چه اطلاعاتی لازم داری؟"),
    Feature("قبض و پرداخت", "مبلغ و تاریخ سررسید", Icons.Default.ReceiptLong,
        "کمکم کن اطلاعات قبض و تاریخ سررسیدش را مرتب کنم."),
    Feature("مشکل گوشی", "راهنمای مرحله‌به‌مرحله", Icons.Default.PhoneAndroid,
        "برای حل یک مشکل گوشی، مرحله‌به‌مرحله راهنمایی‌ام کن."),
    Feature("برنامه‌ریزی کارها", "تبدیل کارها به قدم‌های کوچک", Icons.Default.TaskAlt,
        "این کارها را به یک برنامه ساده و قابل‌اجرا تبدیل کن.")
)

@Composable
private fun RahbaladApp() {
    var page by rememberSaveable { mutableStateOf("خانه") }
    var input by rememberSaveable { mutableStateOf("") }
    val messages = remember {
        mutableStateListOf(
            ChatMessage("سلام! من راه‌بلدم. مشکلت رو بنویس تا کمک کنم راه‌حلش رو پیدا کنی.", false)
        )
    }
    val listState = rememberLazyListState()

    MaterialTheme(colorScheme = lightColorScheme(
        primary = Brand,
        onPrimary = Color.White,
        background = Background,
        surface = Color.White,
        onSurface = Ink
    )) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(modifier = Modifier.fillMaxSize(), color = Background) {
                ScaffoldApp(
                    page = page,
                    onPageChange = { page = it },
                    input = input,
                    onInputChange = { input = it },
                    messages = messages,
                    listState = listState,
                    onSend = {
                        val clean = input.trim()
                        if (clean.isNotEmpty()) {
                            messages.add(ChatMessage(clean, true))
                            messages.add(ChatMessage(demoReply(clean), false))
                            input = ""
                        }
                    },
                    onFeature = { prompt ->
                        messages.add(ChatMessage(prompt, true))
                        messages.add(ChatMessage(demoReply(prompt), false))
                        page = "گفت‌وگو"
                    }
                )
            }
        }
    }
}

@Composable
private fun ScaffoldApp(
    page: String,
    onPageChange: (String) -> Unit,
    input: String,
    onInputChange: (String) -> Unit,
    messages: List<ChatMessage>,
    listState: androidx.compose.foundation.lazy.LazyListState,
    onSend: () -> Unit,
    onFeature: (String) -> Unit
) {
    androidx.compose.material3.Scaffold(
        containerColor = Background,
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                listOf("خانه" to Icons.Default.Home, "گفت‌وگو" to Icons.Default.ChatBubbleOutline,
                    "سوابق" to Icons.Default.History, "پروفایل" to Icons.Default.Settings).forEach { item ->
                    NavigationBarItem(
                        selected = page == item.first,
                        onClick = { onPageChange(item.first) },
                        icon = { Icon(item.second, contentDescription = item.first) },
                        label = { Text(item.first, fontSize = 10.sp) }
                    )
                }
            }
        }
    ) { padding ->
        when (page) {
            "گفت‌وگو" -> ChatPage(
                modifier = Modifier.padding(padding), messages, listState,
                input, onInputChange, onSend
            )
            "سوابق" -> HistoryPage(Modifier.padding(padding), messages)
            "پروفایل" -> ProfilePage(Modifier.padding(padding))
            else -> HomePage(Modifier.padding(padding), onFeature)
        }
    }
}

@Composable
private fun Header() {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Box(
            modifier = Modifier.size(48.dp).background(Brand, RoundedCornerShape(16.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color.White, modifier = Modifier.size(26.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("راه‌بلد", fontSize = 23.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
            Text("دستیار هوشمند کارهای روزمره", fontSize = 11.sp, color = Muted)
        }
        Surface(color = Color(0xFFE3F4F1), shape = CircleShape) {
            Text("نسخه آزمایشی", color = BrandDark, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp))
        }
    }
}

@Composable
private fun HomePage(modifier: Modifier = Modifier, onFeature: (String) -> Unit) {
    LazyColumn(
        modifier = modifier.fillMaxSize().padding(horizontal = 18.dp),
        contentPadding = PaddingValues(top = 18.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Header() }
        item {
            Column {
                Text("از کجا شروع کنیم؟", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink)
                Spacer(Modifier.height(5.dp))
                Text("یک موضوع را انتخاب کن تا قدم‌به‌قدم جلو برویم.", fontSize = 13.sp, color = Muted)
            }
        }
        item {
            Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Brand)) {
                Column(Modifier.fillMaxWidth().padding(18.dp)) {
                    Icon(Icons.Default.Lightbulb, null, tint = Color.White, modifier = Modifier.size(28.dp))
                    Spacer(Modifier.height(9.dp))
                    Text("هر مشکلی، یک قدم تا راه‌حل", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(5.dp))
                    Text("موضوعت را انتخاب کن؛ راه‌بلد مسیر حل آن را برایت مرتب می‌کند.", color = Color.White.copy(alpha = .88f), fontSize = 12.sp)
                }
            }
        }
        item { Text("خدمات راه‌بلد", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Ink) }
        items(features.chunked(2)) { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { feature ->
                    FeatureCard(feature, Modifier.weight(1f)) { onFeature(feature.prompt) }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        item {
            Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CheckCircle, null, tint = Brand)
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("شفاف و مرحله‌ای", fontWeight = FontWeight.Bold, color = Ink, fontSize = 13.sp)
                        Text("قبل از انجام کارهای حساس، اطلاعات را بررسی کن.", color = Muted, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun FeatureCard(feature: Feature, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(
        modifier = modifier.height(112.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(Modifier.fillMaxSize().padding(13.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Icon(feature.icon, contentDescription = feature.title, tint = Brand, modifier = Modifier.size(25.dp))
            Column {
                Text(feature.title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Ink)
                Text(feature.subtitle, fontSize = 10.sp, color = Muted)
            }
        }
    }
}

@Composable
private fun ChatPage(
    modifier: Modifier,
    messages: List<ChatMessage>,
    listState: androidx.compose.foundation.lazy.LazyListState,
    input: String,
    onInputChange: (String) -> Unit,
    onSend: () -> Unit
) {
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex)
    }
    Column(modifier.fillMaxSize().padding(horizontal = 14.dp)) {
        Header()
        Spacer(Modifier.height(12.dp))
        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            state = listState,
            contentPadding = PaddingValues(vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(messages) { message ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (message.fromUser) Arrangement.Start else Arrangement.End
                ) {
                    Surface(
                        color = if (message.fromUser) UserBubble else Color.White,
                        shape = RoundedCornerShape(17.dp),
                        shadowElevation = 1.dp,
                        modifier = Modifier.widthIn(max = 310.dp)
                    ) {
                        Text(message.text, modifier = Modifier.padding(13.dp), color = Ink, fontSize = 13.sp, lineHeight = 21.sp)
                    }
                }
            }
        }
        Row(
            modifier = Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(18.dp)).padding(start = 8.dp, end = 5.dp, top = 5.dp, bottom = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Add, contentDescription = "افزودن فایل در نسخه بعدی", tint = Muted, modifier = Modifier.padding(horizontal = 7.dp))
            TextField(
                value = input,
                onValueChange = onInputChange,
                modifier = Modifier.weight(1f),
                placeholder = { Text("مشکلت رو بنویس...", fontSize = 12.sp) },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent
                ),
                maxLines = 4,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { onSend() })
            )
            IconButton(onClick = onSend, enabled = input.isNotBlank()) {
                Icon(Icons.Default.ArrowUpward, contentDescription = "ارسال", tint = if (input.isNotBlank()) Brand else Muted)
            }
        }
        Spacer(Modifier.height(10.dp))
    }
}

@Composable
private fun HistoryPage(modifier: Modifier, messages: List<ChatMessage>) {
    Column(modifier.fillMaxSize().padding(18.dp)) {
        Header()
        Spacer(Modifier.height(22.dp))
        Text("سوابق گفت‌وگو", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.height(8.dp))
        Text("پیام‌های این نشست در این صفحه نمایش داده می‌شوند.", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(14.dp))
        if (messages.size <= 1) {
            EmptyState("هنوز گفت‌وگویی نداری", "بعد از شروع گفت‌وگو، پیام‌ها اینجا دیده می‌شوند.")
        } else {
            messages.filter { it.fromUser }.forEach { message ->
                Card(Modifier.fillMaxWidth().padding(bottom = 8.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Text(message.text, modifier = Modifier.padding(14.dp), color = Ink, fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
private fun ProfilePage(modifier: Modifier) {
    Column(modifier.fillMaxSize().padding(18.dp)) {
        Header()
        Spacer(Modifier.height(24.dp))
        Text("درباره راه‌بلد", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.height(12.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text("نسخه ۱.۱ آزمایشی", color = Brand, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("راه‌بلد یک نمونه اولیه برای ساده‌کردن کارهای روزمره است. در این نسخه پاسخ‌ها نمایشی‌اند و هنوز سرویس هوش مصنوعی یا اسکن مدارک متصل نشده است.", color = Ink, fontSize = 13.sp, lineHeight = 21.sp)
                Spacer(Modifier.height(10.dp))
                Divider(color = Background)
                Spacer(Modifier.height(10.dp))
                Text("حریم خصوصی", color = Ink, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text("در این نسخه اطلاعات به سرور ارسال نمی‌شود.", color = Muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun EmptyState(title: String, description: String) {
    Column(Modifier.fillMaxWidth().padding(top = 55.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.ChatBubbleOutline, null, tint = Brand, modifier = Modifier.size(38.dp))
        Spacer(Modifier.height(12.dp))
        Text(title, fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.height(5.dp))
        Text(description, color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center)
    }
}

private fun demoReply(query: String): String {
    return "درخواستت رو دریافت کردم:\n«$query»\n\nاین نسخه فعلاً نمایشی است و هنوز به هوش مصنوعی آنلاین وصل نشده. برای راهنمایی دقیق، اطلاعات حساس مثل رمز عبور، کد بانکی یا شماره کامل کارت را ارسال نکن."
}
